import { Component, OnInit,AfterViewInit } from '@angular/core';
import {ServicesService} from './services.service';
import { Http, Response,HttpModule } from '@angular/http';
import { map, startWith } from 'rxjs/operators';
import { Pipe, PipeTransform, Injectable } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ServicesService]


})


/* export class AppComponent implements OnInit { */

  export class AppComponent {

    constructor( public userService: ServicesService) {
    
  }

  title = 'app works!';

  jobDetails:any;

  /*
  ngOnInit()
{
  this.jobDetails = this.userService.loadUser();
}
  */


}